create
    definer = `skip-grants user`@`skip-grants host` procedure addnewbook(IN iType varchar(100), IN iTitle varchar(100),
                                                                         IN iPages int, IN iPrice double,
                                                                         IN iBrief longtext, IN iAuthor varchar(100),
                                                                         IN iNation varchar(100),
                                                                         IN iPress varchar(100))
BEGIN
	#Routine body goes here...
	#SELECT iType,iTitle, iPages,iPrice,iBrief,iAuthor,iNation,iPress;
	DECLARE aid int;
	DECLARE pid int;
	IF((SELECT count(*) FROM author WHERE Author=iAuthor) =1 )THEN
		IF((SELECT count(*) FROM press WHERE Press=iPress) =1 )THEN
			# 出版社和作者都存在的情况
			SET aid= (SELECT ID FROM author WHERE Author=iAuthor);
			SET pid= (SELECT ID FROM press WHERE Press=iPress);
			SELECT aid,pid;
			INSERT INTO books (Type,Title,Pages,Price,Brief,authorid,pressid)VALUES(iType,iTitle, iPages,iPrice,iBrief,aid,pid);
		ELSE
			# 作者存在，出版社不存在的情况
			INSERT INTO press(Press)VALUES(iPress);
			SET aid= (SELECT ID FROM author WHERE Author=iAuthor);
			SET pid= (SELECT ID FROM press WHERE Press=iPress);
			SELECT aid,pid;
			INSERT INTO books (Type,Title,Pages,Price,Brief,authorid,pressid)VALUES(iType,iTitle, iPages,iPrice,iBrief,aid,pid);
		END IF;
	ELSE
		INSERT INTO author(Author,Nation)VALUES(iAuthor,iNation);
		IF((SELECT count(*) FROM press WHERE Press=iPress) =1 )THEN
			# 出版社存在
			SET aid= (SELECT ID FROM author WHERE Author=iAuthor);
			SET pid= (SELECT ID FROM press WHERE Press=iPress);
			SELECT aid,pid;
			INSERT INTO books (Type,Title,Pages,Price,Brief,authorid,pressid)VALUES(iType,iTitle, iPages,iPrice,iBrief,aid,pid);
		ELSE
			# 都不存在
			INSERT INTO press(Press)VALUES(iPress);
			SET aid= (SELECT ID FROM author WHERE Author=iAuthor);
			SET pid= (SELECT ID FROM press WHERE Press=iPress);
			SELECT aid,pid;
			INSERT INTO books (Type,Title,Pages,Price,Brief,authorid,pressid)VALUES(iType,iTitle, iPages,iPrice,iBrief,aid,pid);
		END IF;
	END IF;
END;

