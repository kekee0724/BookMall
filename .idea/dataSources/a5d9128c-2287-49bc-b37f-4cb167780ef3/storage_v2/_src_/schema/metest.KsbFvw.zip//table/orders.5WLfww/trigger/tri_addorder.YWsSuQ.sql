create definer = root@localhost trigger tri_addorder
    after insert
    on orders
    for each row
begin
if  (new.bookid = 1) then
delete from orders where orderid=new.orderid;
end if;
end;

